﻿using Masa.Contrib.Service.Caller.DaprClient;
using Masa.Utils.Models;
using MASA.IoT.Core.Contract.Device;

namespace MASA.IoT.UI.Caller
{
    public class DeviceCaller : DaprCallerBase
    {
        private const string BASE_API = "/api/device";
        protected override string AppId { get; set; } = "masa-iot-service-webapi";

        public Task<PaginatedListBase<DeviceListViewModel>?> DeviceListAsync(DeviceListOption option)
        {
            try
            {
              return Caller.PostAsync<PaginatedListBase<DeviceListViewModel>>($"{BASE_API}/DeviceList", option);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }
             
    }
}
